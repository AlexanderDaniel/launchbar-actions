#!/bin/sh
# Based on https://github.com/toy/blueutil

status=$(/usr/local/bin/blueutil --power)
if [ "$status" == "0" ]; then
	/usr/local/bin/blueutil --power 1
else
	/usr/local/bin/blueutil --power 0
fi